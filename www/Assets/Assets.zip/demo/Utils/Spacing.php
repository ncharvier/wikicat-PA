
<div class="ml-0 bg-info">test</div>
<div class="ml-1 bg-info">test</div>
<div class="ml-2 bg-info">test</div>
<div class="ml-3 bg-info">test</div>
<div class="ml-4 bg-info">test</div>
<div class="ml-5 bg-info">test</div>
<div class="ml-6 bg-info">test</div>
<div class="ml-7 bg-info">test</div>
<div class="ml-8 bg-info">test</div>
<div class="ml-9 bg-info">test</div>
<div class="ml-10 bg-info">test</div>

<br>

<div class="pl-0 bg-info">test</div>
<div class="pl-1 bg-info">test</div>
<div class="pl-2 bg-info">test</div>
<div class="pl-3 bg-info">test</div>
<div class="pl-4 bg-info">test</div>
<div class="pl-5 bg-info">test</div>
<div class="pl-6 bg-info">test</div>
<div class="pl-7 bg-info">test</div>
<div class="pl-8 bg-info">test</div>
<div class="pl-9 bg-info">test</div>
<div class="pl-10 bg-info">test</div>