<div style="width: 40%">
    <div class="form-controller">
        <input type="text" class="form-input" placeholder="Name" name="name" id='name' required />
        <label for="name" class="form-label">Name</label>
    </div>

    <div class="form-controller">
        <input type="password" class="form-input" placeholder="Password" name="password" id='password' required />
        <label for="Password" class="form-label">password</label>
    </div>

    <div class="form-controller">
        <input type="text" class="form-input form-input--validate" placeholder="Success" name="success" id='success' value="success" required />
        <label for="success" class="form-label">Success</label>
    </div>

    <div class="form-controller">
        <input type="text" class="form-input form-input--reject" placeholder="Error" name="error" id='error' value="error"  required />
        <label for="error" class="form-label">Error</label>
    </div>
</div>