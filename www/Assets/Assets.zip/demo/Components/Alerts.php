<div class="alert alert--primary">
    A simple alert
</div>
<div class="alert alert--secondary">
    A simple alert
</div>
<div class="alert alert--danger">
    A simple alert
</div>
<div class="alert alert--warning">
    A simple alert
</div>
<div class="alert alert--success">
    A simple alert
</div>
<div class="alert alert--info">
    A simple alert
</div>

<br>
<br>

<div class="alert alert--primary">
    <h4>My beautifull title </h4>
    <hr>
    A simple alert
</div>
<div class="alert alert--secondary">
    <h4>My beautifull title </h4>
    <hr>
    A simple alert
</div>
<div class="alert alert--danger">
    <h4>My beautifull title </h4>
    <hr>
    A simple alert
</div>
<div class="alert alert--warning">
    <h4>My beautifull title </h4>
    <hr>
    A simple alert
</div>
<div class="alert alert--success">
    <h4>My beautifull title </h4>
    <hr>
    A simple alert
</div>
<div class="alert alert--info">
    <h4>My beautifull title </h4>
    <hr>
    A simple alert
</div>