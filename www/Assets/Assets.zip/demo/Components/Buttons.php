<button class="btn btn--lg btn--primary">test</button>
<button class="btn btn--primary">test</button>
<button class="btn btn--sm btn--primary">test</button>

<br>

<button class="btn btn--lg btn--secondary">test</button>
<button class="btn btn--secondary">test</button>
<button class="btn btn--sm btn--secondary">test</button>

<br>

<button class="btn btn--lg btn--danger">test</button>
<button class="btn btn--danger">test</button>
<button class="btn btn--sm btn--danger">test</button>

<br>

<button class="btn btn--lg btn--warning">test</button>
<button class="btn btn--warning">test</button>
<button class="btn btn--sm btn--warning">test</button>

<br>

<button class="btn btn--lg btn--success">test</button>
<button class="btn btn--success">test</button>
<button class="btn btn--sm btn--success">test</button>

<br>

<button class="btn btn--lg btn--info">test</button>
<button class="btn btn--info">test</button>
<button class="btn btn--sm btn--info">test</button>



<br>
<br>
<br>



<button class="btn btn--lg btn--outline-primary">test</button>
<button class="btn btn--outline-primary">test</button>
<button class="btn btn--sm btn--outline-primary">test</button>

<br>

<button class="btn btn--lg btn--outline-secondary">test</button>
<button class="btn btn--outline-secondary">test</button>
<button class="btn btn--sm btn--outline-secondary">test</button>

<br>

<button class="btn btn--lg btn--outline-danger">test</button>
<button class="btn btn--outline-danger">test</button>
<button class="btn btn--sm btn--outline-danger">test</button>

<br>

<button class="btn btn--lg btn--outline-warning">test</button>
<button class="btn btn--outline-warning">test</button>
<button class="btn btn--sm btn--outline-warning">test</button>

<br>

<button class="btn btn--lg btn--outline-success">test</button>
<button class="btn btn--outline-success">test</button>
<button class="btn btn--sm btn--outline-success">test</button>

<br>

<button class="btn btn--lg btn--outline-info">test</button>
<button class="btn btn--outline-info">test</button>
<button class="btn btn--sm btn--outline-info">test</button>



<br>
<br>
<br>



<button class="btn btn--lg btn--light-primary">test</button>
<button class="btn btn--light-primary">test</button>
<button class="btn btn--sm btn--light-primary">test</button>

<br>

<button class="btn btn--lg btn--light-secondary">test</button>
<button class="btn btn--light-secondary">test</button>
<button class="btn btn--sm btn--light-secondary">test</button>

<br>

<button class="btn btn--lg btn--light-danger">test</button>
<button class="btn btn--light-danger">test</button>
<button class="btn btn--sm btn--light-danger">test</button>

<br>

<button class="btn btn--lg btn--light-warning">test</button>
<button class="btn btn--light-warning">test</button>
<button class="btn btn--sm btn--light-warning">test</button>

<br>

<button class="btn btn--lg btn--light-success">test</button>
<button class="btn btn--light-success">test</button>
<button class="btn btn--sm btn--light-success">test</button>

<br>

<button class="btn btn--lg btn--light-info">test</button>
<button class="btn btn--light-info">test</button>
<button class="btn btn--sm btn--light-info">test</button>

<br>
<br>
<br>

<div class="btn-group">
    <button class="btn btn--info">test</button>
    <button class="btn btn--info">test</button>
    <button class="btn btn--info">test</button>
</div>

<div class="btn-group">
    <button class="btn btn--outline-info">test</button>
    <button class="btn btn--outline-info">test</button>
    <button class="btn btn--outline-info">test</button>
</div>

<div class="btn-group">
    <button class="btn btn--light-info">test</button>
    <button class="btn btn--light-info">test</button>
    <button class="btn btn--light-info">test</button>
</div>

<br>
<br>
<br>

<div class="btn-group">
    <button class="btn btn--danger">test</button>
    <button class="btn btn--warning">test</button>
    <button class="btn btn--secondary">test</button>
    <button class="btn btn--info">test</button>
    <button class="btn btn--primary">test</button>
    <button class="btn btn--success">test</button>
</div>

<div class="btn-group">
    <button class="btn btn--light-danger">test</button>
    <button class="btn btn--light-warning">test</button>
    <button class="btn btn--light-secondary">test</button>
    <button class="btn btn--light-info">test</button>
    <button class="btn btn--light-primary">test</button>
    <button class="btn btn--light-success">test</button>
</div>

<div class="btn-group">
    <button class="btn btn--outline-danger">test</button>
    <button class="btn btn--outline-warning">test</button>
    <button class="btn btn--outline-secondary">test</button>
    <button class="btn btn--outline-info">test</button>
    <button class="btn btn--outline-primary">test</button>
    <button class="btn btn--outline-success">test</button>
</div>